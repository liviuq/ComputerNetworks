#ifndef VERIFY_H_
#define VERIFY_H_

int is_char(char current_char);

#endif